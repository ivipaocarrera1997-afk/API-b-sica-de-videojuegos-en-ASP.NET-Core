namespace ApiVideojuegos.Models
{
    public class VideoJuego
    {
        public int Id {get; set;}
        public string Nombre { get; set;} =string.Empty;
        public string Genero {get; set;}= string.Empty;
        public bool Disponible {get; set;}

    }
}