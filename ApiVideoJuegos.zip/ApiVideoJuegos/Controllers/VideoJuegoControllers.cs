using Microsoft.AspNetCore.Mvc;
using ApiVideojuegos.Models;

namespace ApiVideoJuegos.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VideoJuegosController : ControllerBase
    {
        private static List<VideoJuego> videojuegos = new List<VideoJuego>
        {
            new VideoJuego { Id = 1, Nombre = "God of War", Genero = "Acción",
            Disponible = true },
            new VideoJuego { Id = 2, Nombre = "Minecraft", Genero = "Aventura",
            Disponible = false },
            new VideoJuego {Id= 3, Nombre= "FifaMovil", Genero="futbol", Disponible=true}
        };

        // GET api/videojuegos
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(videojuegos);
        }

        // GET api/videojuegos/1
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var videojuego = videojuegos.FirstOrDefault(i => i.Id == id);
            if (videojuego == null)
            {
                return NotFound();
            }
            return Ok(videojuego);
        }

        // POST api/videojuegos
        [HttpPost]
        public IActionResult Post([FromBody] VideoJuego nuevoVideojuego)
        {
            nuevoVideojuego.Id = videojuegos.Count + 1;
            videojuegos.Add(nuevoVideojuego);
            return Created("", nuevoVideojuego);
        }

        // PUT api/videojuegos/1
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] VideoJuego videojuegoActualizado)
        {
            var videojuego = videojuegos.FirstOrDefault(i => i.Id == id);
            if (videojuego == null)
            {
                return NotFound();
            }
            videojuego.Nombre = videojuegoActualizado.Nombre;
            videojuego.Genero = videojuegoActualizado.Genero;
            videojuego.Disponible = videojuegoActualizado.Disponible;

            return Ok(videojuego);
        }

        // DELETE api/videojuegos/1
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var videojuego = videojuegos.FirstOrDefault(i => i.Id == id);
            if (videojuego == null)
            {
                return NotFound();
            }
            videojuegos.Remove(videojuego);
            return Ok(new { mensaje = "Videojuego eliminado correctamente." });
        }
    }
}